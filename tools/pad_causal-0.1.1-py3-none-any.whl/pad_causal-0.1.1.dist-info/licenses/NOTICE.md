# PaD implementation provenance

This anonymous toolkit 0.1.1 accompanies the GitHub reproducibility release v4
and frozen paper v08, *PaD: When Perturbation Context Changes the Meaning of
Directional Evidence*.

The learning objective, paired one-standard-error selector and five-feature
Proposer were inherited from GitHub release v3. This revision corrects
nonfinite readout handling and validates reverse-pair grouping in custom CV.
The learning weights, regularizers, coefficients and finite-data objective
are unchanged. See `docs/CHANGES.md` and `docs/VALIDATION.md`.

Original reproducibility archive SHA256:
`cec421a46eb3d32b4910a1a83a80d523e555abaa02f674d56e432d9e9613807e`

Frozen paper archive SHA256:
`c185cbc3c675854a651964576feb854a57c5dee958bbf155fe79c92f14100e1a`

The wheel contains the PaD algorithm and its inherited Proposer coefficients.
It does not vendor Réd, CatBoost, XGBoost, benchmark datasets or saved benchmark
models. NumPy, SciPy and scikit-learn remain separately licensed dependencies.
The complete companion experiment repository retains third-party attribution.
