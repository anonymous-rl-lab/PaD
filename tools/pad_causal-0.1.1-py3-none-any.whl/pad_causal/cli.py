"""Command-line fit, prediction and self-contained usage demo."""
import argparse,csv,json
from pathlib import Path
import numpy as np
from . import __version__,Evidence,PaD,endpoint_disjoint_splits

def _pairs(path,n,fold_column=None):
    with Path(path).open(newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
    if len(rows)!=n or not rows or not {'a','b'}<=rows[0].keys():raise ValueError('Pair CSV must contain n rows and a,b columns.')
    pairs=np.array([[r['a'],r['b']] for r in rows]);folds=None
    if fold_column:
        if fold_column not in rows[0]:raise ValueError(f'No {fold_column!r} column in pair CSV.')
        folds=[r[fold_column] for r in rows]
    return pairs,folds

def _write_scores(path,scores):
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(scores.as_dict())
        writer.writerows(zip(*scores.as_dict().values()))

def main(argv=None):
    ap=argparse.ArgumentParser(prog='pad-causal',description='PaD: learn and score joint perturbation evidence.')
    ap.add_argument('--version',action='version',version=__version__)
    sub=ap.add_subparsers(dest='command',required=True)
    demo=sub.add_parser('demo',help='Run a small synthetic training/prediction example')
    demo.add_argument('--output',type=Path,default=Path('pad_demo'))
    fit=sub.add_parser('fit',help='Fit a PaD model from prepared NPZ evidence and labels')
    fit.add_argument('--input',required=True,type=Path);fit.add_argument('--output',required=True,type=Path)
    fit.add_argument('--task',choices=['direction','ranking'],default='direction');fit.add_argument('--pairs',type=Path);fit.add_argument('--fold-column')
    fit.add_argument('--fixed',action='store_true');fit.add_argument('--weights',type=float,nargs=3);fit.add_argument('--regularization',type=float)
    pred=sub.add_parser('predict',help='Write full ordered, reverse, direction and support scores')
    pred.add_argument('--model',required=True,type=Path);pred.add_argument('--input',required=True,type=Path);pred.add_argument('--output',required=True,type=Path)
    args=ap.parse_args(argv)
    try:
        if args.command=='demo':
            from .demo import make_demo
            args.output.mkdir(parents=True,exist_ok=True)
            train,y,pairs=make_demo(64,17);test,truth,_=make_demo(32,29)
            folds=endpoint_disjoint_splits(pairs,np.arange(len(train))%5)
            model=PaD().fit(train,y,pairs=pairs,cv=folds)
            train.save(args.output/'train.npz',y=y);test.save(args.output/'query.npz')
            with (args.output/'pairs.csv').open('w',newline='',encoding='utf-8') as f:
                w=csv.writer(f);w.writerow(['a','b','fold']);w.writerows([list(pair)+[i%5] for i,pair in enumerate(pairs)])
            model.save(args.output/'model.npz');_write_scores(args.output/'scores.csv',model.score_pairs(test))
            print(json.dumps(dict(example='synthetic usage demo',train=64,test=32,accuracy=float(np.mean(model.predict(test)==truth)),weights=model.selected_weights_,regularization=model.regularization_),indent=2));return
        if args.command=='fit':
            evidence=Evidence.from_npz(args.input)
            with np.load(args.input,allow_pickle=False) as z:
                if 'y' not in z:raise ValueError('Training NPZ must contain the separate y array.')
                y=z['y'].copy()
            pairs=None;cv=None
            if args.pairs:
                pairs,folds=_pairs(args.pairs,len(evidence),args.fold_column)
                if not args.fixed:cv=endpoint_disjoint_splits(pairs,folds)
            elif args.fold_column:raise ValueError('--fold-column requires --pairs.')
            model=PaD(task=args.task,selection='fixed' if args.fixed else 'cv',weights=args.weights,regularization=args.regularization).fit(evidence,y,pairs=pairs,cv=cv)
            args.output.parent.mkdir(parents=True,exist_ok=True);model.save(args.output)
            print(json.dumps(dict(n_train=model.n_train_,task=model.task,weights=model.selected_weights_,regularization=model.regularization_,cv_folds=model.n_splits_),indent=2));return
        model=PaD.load(args.model);evidence=Evidence.from_npz(args.input)
        args.output.parent.mkdir(parents=True,exist_ok=True);_write_scores(args.output,model.score_pairs(evidence))
        print(f'Wrote {len(evidence)} paired scores to {args.output}')
    except (ValueError,TypeError,RuntimeError,OSError) as error:ap.error(str(error))
