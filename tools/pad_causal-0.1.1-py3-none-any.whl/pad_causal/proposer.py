"""Frozen five-feature Proposer with the mechanism-interface eight-coordinate summary."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from ._proposer_features import FeatureBuilder
from .readouts import corr
from .validation import _pairs
COEFFICIENTS=np.array([-1.3345139596288158, -0.2021897311472795, -0.11244448155602675, -2.9920029667041446, 0.001908803631124927])
SCALES=np.array([2.2863309511552514, 1.8850613838889343, 12.136152744724322, 2.895593527401924, 0.48928678402894077])

@dataclass(frozen=True)
class ProposerOutput:
    score: np.ndarray
    summary: np.ndarray
    reverse_summary: np.ndarray
    raw_features: np.ndarray

class FrozenProposer:
    """Compute the inherited five-feature score without fitting new coefficients.

    Expression values must be log2-response ratios, with matching p-values.
    Summary coordinates use the exact full-encoder convention of the mechanism
    experiments. Existing biological prepared summaries should be loaded as
    Evidence rather than reconstructed with a different measurement adapter.
    """
    def transform(self,responses,pvalues,pairs,*,genes,interventions):
        e=np.asarray(responses,dtype=float);pv=np.asarray(pvalues,dtype=float)
        genes=[str(x) for x in genes];sources=[str(x) for x in interventions];pairs=_pairs(pairs)
        if e.ndim!=2 or e.shape!=(len(genes),len(sources)) or pv.shape!=e.shape:raise ValueError('responses/pvalues must have shape (len(genes), len(interventions)).')
        if len(set(genes))!=len(genes) or len(set(sources))!=len(sources):raise ValueError('Gene and intervention identifiers must be unique.')
        if not np.isfinite(e).all() or not np.isfinite(pv).all() or np.any((pv<0)|(pv>1)):raise ValueError('Responses must be finite and pvalues must lie in [0, 1].')
        gi={g:i for i,g in enumerate(genes)};si={g:i for i,g in enumerate(sources)}
        if not set(pairs.ravel())<=set(gi):raise ValueError('A pair endpoint is absent from genes.')
        data=dict(sources=sources,gene_index=gi,source_index=si,effect=e,pvalue=pv)
        builder=FeatureBuilder(data);raw=[];summaries=[];scores=[]
        for a,b in pairs:
            mask=~np.isin(sources,[a,b])
            if mask.sum()<4:raise ValueError('At least four third-party interventions must remain after masking A and B.')
            A=e[gi[a],mask];B=e[gi[b],mask];features=builder.feature(a,b);p=float(features@(COEFFICIENTS/SCALES))
            ha=abs(A)>=.5;hb=abs(B)>=.5;union=(ha|hb).sum();shared=(ha&hb).sum()
            xp=np.r_[np.tanh(p/2),corr(A,B),A@B/(np.linalg.norm(A)*np.linalg.norm(B)+1e-9),shared/(union+1),np.tanh(np.log1p(shared)/3),np.tanh(np.log1p(union)/4),np.tanh(np.log(np.std(A)*np.std(B)+1e-8)/4),np.tanh(abs(np.log1p(ha.sum())-np.log1p(hb.sum()))/2)]
            raw.append(features);scores.append(p);summaries.append(xp)
        xp=np.asarray(summaries).reshape(-1,8);rev=xp.copy();rev[:,0]*=-1
        return ProposerOutput(np.array(scores),xp,rev,np.asarray(raw).reshape(-1,5))
