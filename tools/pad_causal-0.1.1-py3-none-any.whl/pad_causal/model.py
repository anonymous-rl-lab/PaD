"""Train, score and serialize the frozen PaD joint kernel."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .evidence import Evidence,PairScores
from .validation import WEIGHTS,REGULARIZERS,_pairs,_pair_ids,endpoint_disjoint_splits,checked_splits,select_scores
from ._kernels import KernelData,fit_grid,fit_model,predict_model

class PaD:
    """Joint perturbation-evidence learner.

    Parameters
    ----------
    task : {'direction', 'ranking'}
        Direction projects the kernel to its antisymmetric component. Ranking
        retains the full ordered score and uses balanced squared loss.
    selection : {'cv', 'fixed'}
        'cv' uses the frozen 35-candidate paired one-SE selection rule. Supply
        pairs or explicit CV folds to fit. 'fixed' fits the specified weights
        and regularization without a search.
    weights : length-3 nonnegative sequence, optional
        Relative P-linear, D-linear and product-kernel weights in fixed mode.
        Defaults to the pure product (0, 0, 1) in that mode; must sum to one.
    regularization : positive float, optional
        Fixed-mode ridge scale. Defaults to 0.003 in fixed mode.
    batch_size : positive int
        Prediction batch size; test-by-test kernels are never constructed.
    """
    def __init__(self,*,task='direction',selection='cv',weights=None,regularization=None,batch_size=512):
        if task not in ['direction','ranking']:raise ValueError('task must be direction or ranking.')
        if selection not in ['cv','fixed']:raise ValueError('selection must be cv or fixed.')
        if not isinstance(batch_size,int) or isinstance(batch_size,bool) or batch_size<1:raise ValueError('batch_size must be a positive integer.')
        if selection=='cv' and (weights is not None or regularization is not None):raise ValueError('For supplied weights/regularization use selection="fixed".')
        w=np.array((0.,0.,1.) if weights is None else weights,dtype=float)
        lam=.003 if regularization is None else float(regularization)
        if w.shape!=(3,) or not np.isfinite(w).all() or np.any(w<0) or not np.isclose(w.sum(),1.,atol=1e-12,rtol=0):raise ValueError('weights must be three finite nonnegative values summing to one.')
        if not np.isfinite(lam) or lam<=0:raise ValueError('regularization must be finite and positive.')
        self.task=task;self.selection=selection;self.weights=weights;self.regularization=regularization;self.batch_size=batch_size
        self._fixed_weights=tuple(w);self._fixed_regularization=lam

    def fit(self,evidence,y,*,pairs=None,cv=None):
        """Select on training-side folds and fit the final model.

        y contains 0/1 labels. A held-out evaluation set must not be passed to
        this method. When pairs are supplied, endpoint separation is checked
        for every fold, including user-supplied folds.
        """
        if not isinstance(evidence,Evidence):raise TypeError('evidence must be an Evidence object.')
        n=len(evidence);yy=np.array(y,dtype=float,copy=True)
        if n<2 or yy.shape!=(n,) or not np.isin(yy,[0.,1.]).all() or len(np.unique(yy))!=2:raise ValueError('Training requires n >= 2 and both 0/1 labels.')
        p=None if pairs is None else _pairs(pairs,n)
        pair_ids=np.array([str(i) for i in range(n)]) if p is None else _pair_ids(p)
        data=KernelData(evidence,yy,self.task=='direction')
        rows=[];fold_count=0
        if self.selection=='cv':
            if cv is None:
                if p is None:raise ValueError('CV selection needs pairs or explicit training-side cv folds.')
                cv=endpoint_disjoint_splits(p)
            folds=checked_splits(cv,n,yy,p)
            scores=np.full((35,n),np.nan)
            for train,val in folds:
                for i,theta in enumerate(WEIGHTS):
                    fitted=fit_grid(data,train,theta)
                    for j,lam in enumerate(REGULARIZERS):scores[i*5+j,val]=fitted[lam][0][val]
            assert np.isfinite(scores).all()
            chosen,rows=select_scores(yy,scores,pair_ids,self.task=='direction')
            i,j=divmod(chosen,5);theta=WEIGHTS[i];lam=REGULARIZERS[j];fold_count=len(folds)
        else:
            if cv is not None:raise ValueError('cv is not used with selection="fixed".')
            theta=self._fixed_weights;lam=self._fixed_regularization
        model=fit_model(data,np.arange(n),theta,lam)
        self._model=model;self.selected_weights_=tuple(float(v) for v in theta);self.regularization_=float(lam)
        self.cv_results_=rows;self.n_splits_=fold_count;self.n_train_=n;self.classes_=np.array([0,1])
        self.feature_dimensions_=(8,evidence.d_odd.shape[1],evidence.d_summary.shape[1])
        self.endpoint_validation_checked_=p is not None and self.selection=='cv'
        return self

    def _check(self,evidence):
        if not hasattr(self,'_model'):raise RuntimeError('PaD is not fitted; call fit or PaD.load first.')
        if not isinstance(evidence,Evidence):raise TypeError('evidence must be an Evidence object.')
        if (8,evidence.d_odd.shape[1],evidence.d_summary.shape[1])!=self.feature_dimensions_:raise ValueError('Query feature dimensions differ from the fitted model.')

    def score_pairs(self,evidence):
        """Return ordered, swapped, directional and symmetric support scores."""
        self._check(evidence);s,r=predict_model(self._model,evidence,self.batch_size)
        return PairScores(s,r,(s-r)/2,(s+r)/2)

    def decision_function(self,evidence):
        """Return direction margins or full ranking scores, according to task."""
        result=self.score_pairs(evidence)
        return result.direction if self.task=='direction' else result.score

    def predict(self,evidence):
        """Apply a zero threshold to the task score, returning binary labels.

        Scores are not calibrated probabilities. In direction mode, 1 means
        the supplied A->B order, and 0 means the reverse; ties map to 1.
        """
        return (self.decision_function(evidence)>=0).astype(int)

    def save(self,path):
        """Save a numeric NPZ model with JSON metadata; no executable pickle."""
        if not hasattr(self,'_model'):raise RuntimeError('Cannot save an unfitted model.')
        m=self._model
        meta=dict(format_version=1,package_version='0.1.1',task=self.task,selection=self.selection,batch_size=self.batch_size,
            selected_weights=list(self.selected_weights_),regularization=self.regularization_,n_train=self.n_train_,
            n_splits=self.n_splits_,cv_results=self.cv_results_,endpoint_validation_checked=self.endpoint_validation_checked_)
        arrays=dict(metadata=np.array(json.dumps(meta)),alpha=m['alpha'],p_scale=np.array(m['p_scale']),odd_scale=m['odd_scale'],odd_norm=np.array(m['odd_norm']))
        arrays.update({'train_'+key:value for key,value in m['train'].items()})
        with Path(path).open('wb') as f:np.savez_compressed(f,**arrays)

    @classmethod
    def load(cls,path):
        """Load and validate the numeric model format saved by PaD.save."""
        with np.load(path,allow_pickle=False) as z:
            try:
                meta=json.loads(str(z['metadata'].item()))
                if meta['format_version']!=1:raise ValueError('Unsupported PaD model format.')
                obj=cls(task=meta['task'],selection='fixed',weights=meta['selected_weights'],regularization=meta['regularization'],batch_size=meta['batch_size'])
                train=Evidence(z['train_p'],z['train_xp'],z['train_odd'],z['train_xd'],z['train_xpr'],z['train_xdr'])
                alpha=np.array(z['alpha'],dtype=float);os=np.array(z['odd_scale'],dtype=float)
                ps=float(z['p_scale']);on=float(z['odd_norm'])
                if alpha.shape!=(len(train),) or os.shape!=(train.d_odd.shape[1],) or not np.isfinite(alpha).all() or not np.isfinite(os).all() or np.any(os<=0) or not np.isfinite([ps,on]).all() or ps<=0 or on<=0:raise ValueError('Invalid fitted model arrays or scales.')
                if meta['n_train']!=len(train):raise ValueError('Model training count mismatch.')
            except (KeyError,TypeError,json.JSONDecodeError) as error:raise ValueError('Invalid PaD model file.') from error
        obj._model=dict(alpha=alpha,theta=np.array(meta['selected_weights']),lam=float(meta['regularization']),p_scale=ps,odd_scale=os,odd_norm=on,directional=meta['task']=='direction',train=train.arrays())
        obj.selected_weights_=tuple(meta['selected_weights']);obj.regularization_=float(meta['regularization']);obj.n_train_=len(train)
        obj.cv_results_=meta.get('cv_results',[]);obj.n_splits_=meta.get('n_splits',0);obj.endpoint_validation_checked_=meta.get('endpoint_validation_checked',False)
        obj.feature_dimensions_=(8,train.d_odd.shape[1],train.d_summary.shape[1]);obj.classes_=np.array([0,1])
        # Loading produces a fixed fitted model; a later .fit explicitly refits that selected configuration.
        return obj
