"""Small synthetic usage example; not a paper benchmark or calibrated assay."""
import numpy as np
from .evidence import Evidence
from .proposer import FrozenProposer
from .readouts import corr,double_features

def make_demo(n=64,random_state=17):
    """Return (Evidence, y, pairs) from positive-expression mechanism states."""
    if not isinstance(n,int) or n<8:raise ValueError('n must be an integer >= 8.')
    rng=np.random.default_rng(random_state);Y=rng.choice([-1,1],n);C=rng.choice([-1,1],n)
    if len(set(Y))!=2:Y[0]=-Y[0]
    zp=rng.standard_normal(n);zd=.5*zp+np.sqrt(.75)*rng.standard_normal(n)
    X=.5*C+zp;Q=2*C+zd;T=Y*C;z=np.array([-.8,.8,-.6,.6,-.4,.4,0.])
    p=[];xp=[];xd=[];encoder=FrozenProposer()
    for i in range(n):
        A=np.exp(X[i]-.3*T[i])*z;B=np.exp(X[i]+.3*T[i])*z
        output=encoder.transform(np.array([A,B]),np.full((2,7),.001),[['A','B']],genes=['A','B'],interventions=[f'E{j}' for j in range(7)])
        ga=np.zeros(7);gb=np.zeros(7)
        if Y[i]>0:gb[-1]=np.exp(Q[i])
        else:ga[-1]=np.exp(Q[i])
        ss,dd,qq=double_features(np.array([0.]),np.array([0.]),np.array([0.]),np.array([0.]))
        ctx=[corr(ga,gb),corr(ga,gb),np.tanh(np.log1p(7)/4),np.tanh(np.mean(abs(ga-gb))),np.mean(np.sign(ga)==np.sign(gb))]
        summary=np.r_[np.tanh(ss[0]/.5),np.tanh(dd[0]),qq[0,:3],np.tanh(qq[0,3]),.5,2.,0.,0.,0.,0.,ctx]
        p.append(output.score[0]);xp.append(output.summary[0]);xd.append(summary)
    pairs=np.array([[f'{random_state}_{i}_A',f'{random_state}_{i}_B'] for i in range(n)])
    return Evidence(p,xp,np.zeros((n,8)),xd),(Y>0).astype(int),pairs
