"""Validated, label-free paired perturbation inputs."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np

def _array(value, name, ndim):
    a=np.array(value,dtype=float,copy=True)
    if a.ndim!=ndim or not np.isfinite(a).all():
        raise ValueError(f'{name} must be a finite {ndim}-dimensional numeric array.')
    return a

@dataclass(frozen=True)
class Evidence:
    """The frozen PaD feature interface.

    p_score: (n,) frozen Proposer scores.
    p_summary: (n, 8), first coordinate odd under pair exchange; others even.
    d_odd: (n, q) raw directional double-perturbation features.
    d_summary: (n, k), k >= q; first q coordinates odd, others even.

    Missing measurements must already be represented by the adapter's finite
    feature values and masks. Labels are passed separately to PaD.fit.
    """
    p_score: np.ndarray
    p_summary: np.ndarray
    d_odd: np.ndarray
    d_summary: np.ndarray
    p_reverse: np.ndarray | None = None
    d_reverse: np.ndarray | None = None

    def __post_init__(self):
        p=_array(self.p_score,'p_score',1);xp=_array(self.p_summary,'p_summary',2)
        odd=_array(self.d_odd,'d_odd',2);xd=_array(self.d_summary,'d_summary',2)
        n=len(p)
        if xp.shape!=(n,8):raise ValueError('p_summary must have shape (n, 8).')
        if odd.shape[0]!=n or odd.shape[1]<1:raise ValueError('d_odd must have shape (n, q), q >= 1.')
        if xd.shape[0]!=n or xd.shape[1]<odd.shape[1]:raise ValueError('d_summary must have n rows and at least q columns.')
        xpr=xp.copy();xpr[:,0]*=-1
        xdr=xd.copy();xdr[:,:odd.shape[1]]*=-1
        for name,given,expected in [('p_reverse',self.p_reverse,xpr),('d_reverse',self.d_reverse,xdr)]:
            if given is not None:
                arr=_array(given,name,2)
                if arr.shape!=expected.shape or not np.allclose(arr,expected,rtol=0,atol=1e-10):
                    raise ValueError(f'{name} violates the frozen column exchange rule.')
                if name=='p_reverse':xpr=arr
                else:xdr=arr
        for key,arr in [('p_score',p),('p_summary',xp),('d_odd',odd),('d_summary',xd),('p_reverse',xpr),('d_reverse',xdr)]:
            arr.setflags(write=False);object.__setattr__(self,key,arr)

    def __len__(self):return len(self.p_score)

    def take(self, indices):
        """Return a row subset. Integer arrays, masks and slices are accepted."""
        ix=np.arange(len(self))[indices]
        ix=np.atleast_1d(ix)
        return Evidence(self.p_score[ix],self.p_summary[ix],self.d_odd[ix],self.d_summary[ix],self.p_reverse[ix],self.d_reverse[ix])

    def swapped(self):
        """Exchange A and B, without using or modifying any label."""
        return Evidence(-self.p_score,self.p_reverse,-self.d_odd,self.d_reverse,self.p_summary,self.d_summary)

    def arrays(self):
        """Return arrays under the original reproduction-package NPZ keys."""
        return dict(p=self.p_score,xp=self.p_summary,odd=self.d_odd,xd=self.d_summary,xpr=self.p_reverse,xdr=self.d_reverse)

    def save(self,path,*,y=None):
        """Write portable NPZ inputs; optional labels are stored separately."""
        arrays=self.arrays()
        if y is not None:
            yy=np.asarray(y)
            if yy.shape!=(len(self),) or not np.isin(yy,[0,1]).all():raise ValueError('y must contain n binary 0/1 labels.')
            arrays['y']=yy
        with Path(path).open('wb') as f:np.savez_compressed(f,**arrays)

    @classmethod
    def from_npz(cls,path):
        """Load prepared inputs. Stored y/directional fields are not features."""
        with np.load(path,allow_pickle=False) as z:
            required=['p','xp','odd','xd']
            missing=set(required)-set(z.files)
            if missing:raise ValueError(f'Missing NPZ arrays: {sorted(missing)}')
            return cls(z['p'],z['xp'],z['odd'],z['xd'],z['xpr'] if 'xpr' in z else None,z['xdr'] if 'xdr' in z else None)

@dataclass(frozen=True)
class PairScores:
    """Full ordered, reverse, directional, and symmetric support scores."""
    score: np.ndarray
    reverse_score: np.ndarray
    direction: np.ndarray
    support: np.ndarray

    def as_dict(self):
        return dict(score=self.score,reverse_score=self.reverse_score,direction=self.direction,support=self.support)

def load_evidence(path):
    """Convenience alias for Evidence.from_npz; labels are never returned."""
    return Evidence.from_npz(path)
