"""Literal frozen kernel definitions and spectral ridge objective."""
import numpy as np
from scipy.linalg import eigh
from .validation import REGULARIZERS

def rbf(a,b,width=.5):
    d=np.maximum((a*a).mean(1)[:,None]+(b*b).mean(1)[None,:]-2*a@b.T/a.shape[1],0.)
    return np.exp(-d/(2*width*width))

def rms(x):
    s=np.sqrt(np.mean(x*x,axis=0));return np.where(s<1e-8,1.,s)

class KernelData:
    def __init__(self,evidence,y,directional):
        self.z=evidence.arrays();self.y=y;self.directional=directional
        z=self.z;self.J=rbf(z['xp'],z['xp'])*rbf(z['xd'],z['xd']);self.Jr=rbf(z['xpr'],z['xp'])*rbf(z['xdr'],z['xd'])

    def components(self,tr):
        z=self.z;p=z['p']/float(rms(z['p'][tr,None])[0]);o=np.clip(z['odd']/rms(z['odd'][tr]),-8,8)
        onorm=max(float(np.mean(np.sum(o[tr]*o[tr],axis=1))),1e-8)
        kp=p[:,None]*p[None,:];kd=o@o.T/onorm
        return [kp,kd,self.J],[-kp,-kd,self.Jr]

def fit_grid(data,tr,theta,lambdas=REGULARIZERS):
    tr=np.asarray(tr,int);cc,rr=data.components(tr);K=sum(t*c for t,c in zip(theta,cc));Kr=sum(t*c for t,c in zip(theta,rr))
    if data.directional:K=(K-Kr)/2;Kr=-K
    yy=data.y[tr];w=np.ones(len(tr))
    if not data.directional:
        n1=max(int(yy.sum()),1);n0=max(len(tr)-int(yy.sum()),1);w=np.where(yy>0,len(tr)/(2*n1),len(tr)/(2*n0))
    sw=np.sqrt(w);M=K[np.ix_(tr,tr)]*sw[:,None]*sw[None,:];v,U=eigh(M,check_finite=False);v=np.maximum(v,0.)
    rhs=U.T@(sw*(2*yy-1));alphas=np.column_stack([sw*(U@(rhs/(v+lam*len(tr)))) for lam in lambdas])
    ps=K[:,tr]@alphas;prs=Kr[:,tr]@alphas
    return {lam:(ps[:,j],prs[:,j]) for j,lam in enumerate(lambdas)}

def fit_model(data,tr,theta,lam):
    tr=np.asarray(tr,int);cc,rr=data.components(tr)
    K=sum(t*c for t,c in zip(theta,cc));R=sum(t*c for t,c in zip(theta,rr))
    if data.directional:K=(K-R)/2
    y=data.y[tr];w=np.ones(len(tr))
    if not data.directional:
        n1=max(int(y.sum()),1);n0=max(len(tr)-int(y.sum()),1);w=np.where(y>0,len(tr)/(2*n1),len(tr)/(2*n0))
    sw=np.sqrt(w);v,U=eigh(K[np.ix_(tr,tr)]*sw[:,None]*sw[None,:],check_finite=False);v=np.maximum(v,0)
    alpha=sw*(U@((U.T@(sw*(2*y-1)))/(v+lam*len(tr))))
    z=data.z;ps=float(rms(z['p'][tr,None])[0]);os=rms(z['odd'][tr]);o=np.clip(z['odd'][tr]/os,-8,8)
    onorm=max(float(np.mean(np.sum(o*o,axis=1))),1e-8)
    return dict(alpha=alpha,theta=np.asarray(theta),lam=float(lam),p_scale=ps,odd_scale=os,odd_norm=onorm,directional=data.directional,train={key:z[key][tr].copy() for key in ['p','odd','xp','xpr','xd','xdr']})

def predict_model(model,evidence,batch=512):
    z=evidence.arrays();n=len(evidence);s=np.empty(n);sr=np.empty(n);tz=model['train']
    pt=tz['p']/model['p_scale'];ot=np.clip(tz['odd']/model['odd_scale'],-8,8)
    for lo in range(0,n,batch):
        ix=slice(lo,min(n,lo+batch));P=rbf(z['xp'][ix],tz['xp']);Pr=rbf(z['xpr'][ix],tz['xp'])
        D=rbf(z['xd'][ix],tz['xd']);Dr=rbf(z['xdr'][ix],tz['xd'])
        kp=(z['p'][ix]/model['p_scale'])[:,None]*pt
        kd=np.clip(z['odd'][ix]/model['odd_scale'],-8,8)@ot.T/model['odd_norm']
        cc=[kp,kd,P*D];rr=[-kp,-kd,Pr*Dr]
        K=sum(t*c for t,c in zip(model['theta'],cc));R=sum(t*c for t,c in zip(model['theta'],rr))
        if model['directional']:K=(K-R)/2;R=-K
        s[ix]=K@model['alpha'];sr[ix]=R@model['alpha']
    return s,sr
