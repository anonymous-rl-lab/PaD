"""Endpoint-excluded folds and the original paired selection rule."""
from __future__ import annotations
import numpy as np
from sklearn.metrics import roc_auc_score

WEIGHTS=((1.,0.,0.),(0.,1.,0.),(0.,0.,1.),(.5,.5,0.),(.5,0.,.5),(0.,.5,.5),(1/3,1/3,1/3))
REGULARIZERS=(.00003,.0003,.003,.03,.3)

def _pairs(pairs,n=None):
    p=np.asarray(pairs,dtype=str)
    if p.ndim!=2 or p.shape[1]!=2 or (n is not None and len(p)!=n):raise ValueError('pairs must have shape (n, 2).')
    if np.any(p=='') or np.any(p[:,0]==p[:,1]):raise ValueError('Pair endpoints must be nonempty and distinct.')
    return p

def _pair_ids(pairs):
    # JSON-style tuple identities avoid separator collisions in arbitrary gene names.
    import json
    return np.array([json.dumps(sorted(row),separators=(',',':')) for row in pairs])

def endpoint_disjoint_splits(pairs,fold_ids=None):
    """Yield folds excluding every validation endpoint from the training set.

    Without fold_ids, each unordered pair is one validation group. With
    fold_ids, records in a group are held out together. Reverse records must
    share a group. Empty training sets are reported, not silently replaced.
    """
    p=_pairs(pairs);ids=_pair_ids(p)
    groups=ids if fold_ids is None else np.asarray(fold_ids)
    if groups.shape!=(len(p),):raise ValueError('fold_ids must have n elements.')
    if any(v is None or (isinstance(v,(float,np.floating)) and not np.isfinite(v)) for v in groups):raise ValueError('fold_ids cannot contain missing values.')
    groups=groups.astype(str)
    for key in np.unique(ids):
        if len(np.unique(groups[ids==key]))!=1:raise ValueError('Reverse records must share a validation group.')
    for key in dict.fromkeys(groups):
        val=np.flatnonzero(groups==key);ends=np.unique(p[val]);train=np.flatnonzero(~np.isin(p,ends).any(axis=1))
        if not len(train):raise ValueError(f'Validation group {key!r} leaves no endpoint-disjoint training records.')
        yield train,val

def checked_splits(cv,n,y,pairs=None):
    out=[];seen=np.zeros(n,int);validation_fold=np.full(n,-1,int)
    for fold_index,(train,val) in enumerate(cv):
        tr=np.asarray(train);te=np.asarray(val)
        if tr.ndim!=1 or te.ndim!=1 or not np.issubdtype(tr.dtype,np.integer) or not np.issubdtype(te.dtype,np.integer):raise ValueError('CV indices must be one-dimensional integer arrays.')
        if not len(tr) or not len(te):raise ValueError('Every CV fold needs training and validation records.')
        if np.any(tr<0) or np.any(te<0) or np.any(tr>=n) or np.any(te>=n):raise ValueError('CV index out of range.')
        if len(np.unique(tr))!=len(tr) or len(np.unique(te))!=len(te) or np.intersect1d(tr,te).size:raise ValueError('CV indices repeat or training overlaps validation.')
        if len(np.unique(y[tr]))!=2:raise ValueError('Each CV training fold must contain both labels.')
        if pairs is not None and np.intersect1d(pairs[tr].ravel(),pairs[te].ravel()).size:raise ValueError('CV training contains a validation endpoint.')
        seen[te]+=1;validation_fold[te]=fold_index;out.append((tr.astype(int),te.astype(int)))
    if len(out)<2 or not np.all(seen==1):raise ValueError('CV must validate every record exactly once in at least two folds.')
    if pairs is not None:
        ids=_pair_ids(pairs)
        for key in np.unique(ids):
            if len(np.unique(validation_fold[ids==key]))!=1:
                raise ValueError('Reverse records must share a validation group, including custom CV folds.')
    return out

def paired_se(y,score,best,pairs,directional):
    if directional:
        delta=((best>=0)==(y>0)).astype(float)-((score>=0)==(y>0)).astype(float)
        influence=(delta-delta.mean())/len(y)
    else:
        pos=np.flatnonzero(y>0);neg=np.flatnonzero(y==0)
        def concordance(s):
            d=s[pos,None]-s[None,neg];return (d>0).astype(float)+.5*(d==0)
        d=concordance(best)-concordance(score);mu=d.mean();influence=np.zeros(len(y));influence[pos]=(d.mean(1)-mu)/len(pos);influence[neg]=(d.mean(0)-mu)/len(neg)
    unique,idx=np.unique(pairs,return_inverse=True);v=np.bincount(idx,weights=influence);n=len(unique)
    return float(np.sqrt(np.sum(v*v)*n/max(n-1,1)))

def select_scores(y,s,pair_ids,directional):
    configs=[(i,lam) for i in range(len(WEIGHTS)) for lam in REGULARIZERS]
    primary=[];loss=[]
    for score in s:
        primary.append(float(np.mean((score>=0)==(y>0))) if directional else float(roc_auc_score(y,score)))
        v=(2*y-1-score)**2
        loss.append(float(v.mean()) if directional else float((v[y>0].mean()+v[y==0].mean())/2))
    primary=np.array(primary);loss=np.array(loss)
    best=min(range(len(configs)),key=lambda j:(-primary[j],loss[j],-configs[j][1],configs[j][0]))
    gap=primary[best]-primary;se=np.array([paired_se(y,v,s[best],pair_ids,directional) for v in s])
    eligible=np.flatnonzero(gap<=se+1e-12)
    chosen=min(eligible,key=lambda j:(-configs[j][1],-primary[j],loss[j],configs[j][0]))
    rows=[dict(weights=WEIGHTS[i],regularization=lam,primary=float(primary[j]),squared_loss=float(loss[j]),gap=float(gap[j]),paired_se=float(se[j]),eligible=bool(j in eligible),selected=bool(j==chosen)) for j,(i,lam) in enumerate(configs)]
    return chosen,rows
